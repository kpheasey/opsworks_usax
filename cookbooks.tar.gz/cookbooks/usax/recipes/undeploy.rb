# frozen_string_literal: true
#
# Cookbook Name:: usax
# Recipe:: undeploy
#

include_recipe 'opsworks_ruby::undeploy'
