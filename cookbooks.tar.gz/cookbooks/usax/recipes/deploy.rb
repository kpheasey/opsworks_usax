# frozen_string_literal: true
#
# Cookbook Name:: usax
# Recipe:: deploy
#

include_recipe 'opsworks_ruby::deploy'