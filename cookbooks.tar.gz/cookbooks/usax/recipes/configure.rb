# frozen_string_literal: true
#
# Cookbook Name:: usax
# Recipe:: configure
#

include_recipe 'opsworks_ruby::configure'
