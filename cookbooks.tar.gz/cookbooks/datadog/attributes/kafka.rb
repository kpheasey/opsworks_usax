default['datadog']['kafka']['version'] = 1
