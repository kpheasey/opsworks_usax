include_recipe 'chef-solr::install'
include_recipe 'chef-solr::configure'
