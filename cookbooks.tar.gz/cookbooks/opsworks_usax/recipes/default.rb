#
# Cookbook Name:: opsworks_usax
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.
