7-zip Cookbook CHANGELOG
========================
This file is used to list changes made in each version of the 7-zip cookbook.


v1.0.2
------
### Improvement
- **[COOK-3476](https://tickets.opscode.com/browse/COOK-3476)** - Upgrade to 7-zip 9.22

1.0.0
-----
- initial release
